# VetReach

**An Interactive Multi-Service Veterinary Outreach Planning and Resource Allocation System for Local Government Units in the Philippines**

GED104 academic prototype. All municipality, barangay, staff and resource data is **fictional**.

---

## 1. Running it

No installs, no server, no internet needed (except to load the two Google Fonts; system fonts are used otherwise).

1. Open the `vetreach` folder.
2. Double-click `index.html`. It opens in Chrome, Edge, Firefox or Safari.

Optional local server (Windows): `powershell -ExecutionPolicy Bypass -File serve.ps1`, then open http://localhost:8080.

Data is saved in the browser (`localStorage`), so refreshing keeps your changes. **Reset demo** (bottom of the sidebar on desktop) restores the original scenario.

**First visit:** a short guided tutorial (5 steps) explains the app. Replay it any time with **Tutorial** in the sidebar (or the **?** button on phones). Keys: → / ← to move, Esc to close.

## Pages

| Page | What it does |
|---|---|
| Home | Greeting, the three steps of the job (review requests, check resources, make the plan) with one main button, coming-up visits and anything that needs attention |
| Requests | Add, edit, remove, search and filter requests. "How priority is decided" (collapsed) holds the scores and weight sliders |
| Resources | Tabs for Teams, Vehicles, and Supplies & budget |
| Plan | Generate, review, change, undo and approve. Switch between **List** and **Calendar** (month / week / day). Drag a visit to another day to move it (checked first; conflicts open the editor with alternatives) |
| Reports | KPIs, charts, coverage and schedule tables, change log, print and CSV export |

## 2. Files

| File | Purpose |
|---|---|
| `index.html` | App shell: sidebar / bottom navigation, icon sprite, dialog and toast containers |
| `styles.css` | Design tokens (light and dark), components, responsive layouts, motion, print styles |
| `app.js` | Demo data, planning engine, views, dialogs and event handling |
| `assets/logo.svg` | Brand mark: a location pin holding a paw (outreach + veterinary care) |
| `serve.ps1` | Optional tiny static server |

## 3. Architecture

Plain HTML, CSS and JavaScript. No framework, no build step, no libraries.

- **One state object** (`state`) holds barangays, requests, teams, vehicles, supplies, budget, the current plan, undo history and a change log. Every change calls `save()`, which writes it to `localStorage`.
- **Data-driven rendering.** Each page is a function (`renderOverview`, `renderCommunities`, …) that returns HTML built from `state`. `render()` picks the page from the URL hash (`#/planner`). Every dynamic value goes through `esc()` before it is inserted as HTML.
- **Event delegation.** Buttons carry `data-action="…"`. One click listener looks the name up in an `actions` table. Inputs use `data-change` the same way.
- **Native browser features:** `<dialog>` for modals (it handles focus and Esc), `<details>` for expandable sections, `window.print()` for reports, and a `Blob` download for CSV export.

## 4. Planning algorithm

### 4.1 Priority score (0–100)
Each request gets four factors, each between 0 and 1:

| Factor | Formula | Default weight |
|---|---|---|
| Demand | animals ÷ largest request in the same animal category | 35 |
| Coverage gap | days since the barangay's last visit ÷ 365 (max 1) | 25 |
| Waiting time | days since the request was filed ÷ 90 (max 1) | 20 |
| Accessibility | (access level − 1) ÷ 2. Remote = 1, easy = 0 | 20 |

`score = Σ (weight × factor) ÷ Σ weights × 100`

The weights are **prototype assumptions**. The administrator can change them with sliders in Requests › How priority is decided, and the page shows how much each factor adds to every barangay's score. The score only decides which request is scheduled first. It does not measure a community's worth.

### 4.2 Generating a plan (greedy, explainable)
1. Sort all requests by priority score, highest first.
2. For each request, work out what it needs: supply quantity (`animals × per-animal use`), team-days (`animals ÷ daily capacity`, rounded up) and cost (`base + per-animal × animals + travel × days`).
3. If no team has the required qualification, or not enough supplies or budget are left, leave the request unscheduled and record the reason.
4. Otherwise try start days (preferred dates first). For each day, try qualified teams (fewest qualifications first, so specialists stay free) that are available and not booked on every day of the visit. Then find a free vehicle. Remote barangays require the 4×4, and other barangays use vans first.
5. Take the first slot that works, subtract its supplies and cost, and continue.
6. Show the result as a **suggested** plan. Nothing is final until the administrator presses **Approve plan**.

This method is simple and transparent. It is not guaranteed to be optimal.

### 4.3 Validation and replanning
`validate(activities)` re-checks any plan against the current data:
qualification · team availability · team double-booking · vehicle availability · vehicle double-booking · 4×4 requirement · planning window · total supplies · total budget.

When the administrator changes an assignment, the **Change assignment** dialog builds a draft plan and validates it before anything is saved. The preview shows:
- problems with the edited visit, and any new problems it causes for other visits,
- coverage effects. For example, "Malinao will no longer have a scheduled rabies vaccination visit," with an option to keep it covered by another free team,
- up to three **valid alternatives**, each checked against every rule.

**Apply change** stays disabled until the draft is conflict-free. Each applied change can be undone. Editing an approved plan returns it to "suggested". The plan is also re-validated whenever requests or resources change, and affected visits are flagged.

## 5. Demo data

Fictional **Municipality of Mabini Verde**: 7 barangays (2 remote), 15 requests covering companion animals, livestock and poultry, 4 teams with different qualifications, 3 vehicles (one 4×4), 7 supply types, and a ₱90,000 budget. The planning window is 10 working days from 23 Nov 2026, skipping weekends and holidays (30 Nov Bonifacio Day).

Built-in scenarios:
- **Not everything fits.** Anti-rabies vaccine (800 doses for 960 requested) and spay/neuter kits (40 for 55) run short, so 2 requests stay unscheduled, each with its reason.
- **An edit causes a conflict.** Assign Team Ilang-Ilang (AI technicians only) to a rabies visit, or remove a qualification or day in Resources. The plan flags the conflict and suggests valid fixes.

## 6. Five-minute demonstration

| Time | Do this | Point out |
|---|---|---|
| 0:00 | Open **Home** (the tutorial shows on first visit) | Fictional-data tag, the three steps, one main button |
| 0:30 | **Requests**: filter *Livestock*, search "Mal" | Priority scores. Open "How priority is decided", drag the *Accessibility* slider and watch the ranking change |
| 1:15 | **Resources**: tap a day off for Team Narra; in *Supplies & budget* set Anti-rabies vaccine to 600 | Changes save instantly |
| 1:45 | **Generate plan** | "Plan ready" card, schedule by day, *Couldn't schedule* list with reasons, meters |
| 2:30 | On Malinao's rabies visit, press **Change** and pick **Team Ilang-Ilang** | Clear conflict explanation and valid alternatives |
| 3:15 | Click an alternative, then **Apply change** | Highlighted update, toast with Undo, "Conflict resolved" |
| 3:45 | Change Malinao's rabies visit to serve San Roque's rabies request | Coverage warning that Malinao's request loses its slot, with a free team offered to keep it covered (a barangay with no other visits gets "will no longer have a scheduled … visit") |
| 4:00 | In **Plan**, switch to **Calendar** and drag a visit to another day | Valid moves apply with Undo; a clash opens the editor with the reason and alternatives |
| 4:15 | **Approve plan**, then open **Reports** | Coverage table, service and resource charts, conflicts resolved, Print / Export CSV |
| 4:45 | Toggle **dark mode**, show the phone layout | Responsive design and an intentional dark palette |

## 7. Functional testing checklist

- [x] Add a request: validation shows next to the field (animals 1–20,000, "preferred until" ≥ "from")
- [x] Edit and remove a request (removal asks for confirmation)
- [x] Search by barangay and filter by category
- [x] Weight sliders re-rank requests live
- [x] Toggle team qualifications and team/vehicle days. Edit supplies and budget. The toast reports new or cleared conflicts
- [x] Generate a plan. Unscheduled requests show their reasons
- [x] Change team / date / vehicle / request. Invalid changes are blocked with explanations and valid alternatives
- [x] Moving a visit warns about lost coverage and offers a free team
- [x] Find a slot for an unscheduled request
- [x] Remove an activity, undo it, regenerate
- [x] Approve the plan (blocked while conflicts exist). Editing returns it to suggested
- [x] Reports update. CSV export and print work
- [x] Plan › Calendar: month / week / day views, previous / next, "Plan start"; holidays and weekends hatched
- [x] Calendar drag-and-drop: valid move applies with Undo; conflicting move opens the editor with alternatives
- [x] Tutorial appears on first visit only, can be replayed, works on phone (points at the bottom bar), Esc closes it
- [x] Refresh keeps data. Reset demo data restores it
- [x] Light/dark mode follows the system and remembers a manual choice
- [x] Layouts tested at 375 px (phone, bottom nav), 900 px (tablet, icon rail) and 1024 px+ (desktop sidebar), with no horizontal scrolling
- [x] Keyboard: skip link, visible focus rings, dialogs close with Esc, focus returns after re-render
- [x] `prefers-reduced-motion` turns animations off. Status is never shown by colour alone (icon + text)
- [x] No console errors

## 8. Colour meanings

The look is a calm "floating app card": a dusty-blue sidebar, rounded white panels and one navy accent for the main action.

| Colour | Used for |
|---|---|
| Dusty Blue `#B8CCE2` / `#C4D6EA` | Sidebar, brand, navigation, selection, available days |
| Navy `#2E3D58` | Primary buttons, highlight cards, progress, selected day |
| Sage `#BCD6C2` | Feasible or approved states, livestock |
| Butter Yellow `#F2E3AE` | Gentle emphasis, poultry, "outside preferred dates" |
| Dusty Peach `#F2D2C2` | Companion animals |
| Lavender Mist `#DAD4EE` | Secondary information, "remote barangay", unavailable resources |
| Soft White `#F5F7FA` / Navy Ink `#24314A` | Background and primary text |

Conflicts use a muted terracotta that always comes with an alert icon and a written explanation.
